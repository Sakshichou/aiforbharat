import uuid
import enum
from sqlalchemy import Column, String, Text, DateTime, Enum, func
from sqlalchemy.dialects.postgresql import UUID
from app.db.database import Base

class ReportStatus(str, enum.Enum):
    PENDING = "Pending"
    RESOLVED = "Resolved"

class Report(Base):
    __tablename__ = "reports"

    report_id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4, index=True)
    user_id = Column(String(255), nullable=False, index=True)
    ward_area = Column(String(255), nullable=False)
    description = Column(Text, nullable=False)
    ai_category = Column(String(100), nullable=True)
    status = Column(Enum(ReportStatus), default=ReportStatus.PENDING)
    evidence_url = Column(String(1024), nullable=True) # S3 link
    timestamp = Column(DateTime(timezone=True), server_default=func.now())
