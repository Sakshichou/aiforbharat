from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.db.database import get_db
from app.db.models import Report
from app.schemas.report import ReportCreate, ReportResponse
from app.core.auth import get_current_user

router = APIRouter()

@router.post("", response_model=ReportResponse)
def create_report(
    report: ReportCreate,
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """
    Create a new report under the logged in user's profile.
    """
    new_report = Report(
        user_id=current_user["user_id"],
        ward_area=report.ward_area,
        description=report.description,
        evidence_url=report.evidence_url,
        ai_category=report.ai_category
    )
    db.add(new_report)
    db.commit()
    db.refresh(new_report)
    return new_report

@router.get("", response_model=list[ReportResponse])
def get_reports(
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """
    Retrieve reports created by the current user.
    """
    reports = db.query(Report).filter(Report.user_id == current_user["user_id"]).all()
    return reports
